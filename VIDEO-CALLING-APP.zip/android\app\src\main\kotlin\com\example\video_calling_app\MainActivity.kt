package com.example.video_calling_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
