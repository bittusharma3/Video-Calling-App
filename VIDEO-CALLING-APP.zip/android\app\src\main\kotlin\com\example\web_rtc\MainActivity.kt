package com.example.web_rtc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
